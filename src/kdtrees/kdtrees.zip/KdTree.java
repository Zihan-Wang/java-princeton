/*package kdtrees;*/
import edu.princeton.cs.algs4.Point2D;
import edu.princeton.cs.algs4.RectHV;
import java.lang.IllegalArgumentException;
import edu.princeton.cs.algs4.StdDraw;
import edu.princeton.cs.algs4.Queue;
import edu.princeton.cs.algs4.StdOut;



public class KdTree {
	private node root;
	private int size;
	private boolean now;
	private Point2D near;
	private class node {
		private Point2D point;
		private boolean direction;
		private RectHV rect;
		private node left;
		private node right;
		public node(Point2D p) {
			this.point = p;
		}
	}
	
	public KdTree() {
	}
	
	public boolean isEmpty() {
		if(size == 0)return true;
		return false;
	 }
	 
	public int size() {
		return size;
	 }
	 
	public void insert(Point2D p) {
		wrong(p);
		if(contains(p))return;
		node a = new node(p);
		if(size == 0) {
			root = a;
			root.direction = true;
			root.rect = new RectHV(0, 0, 1, 1);
			size++;
			return;
		}
		root = insert(root, a, 0, 1, 0, 1);
		size++;
	 }
	private node insert(node q, node p, double xmin, double xmax, double ymin, double ymax) {
		if(q==null) {
			q = new node(p.point);
			q.rect = new RectHV(xmin, ymin, xmax, ymax);
		    q.direction = now;
			return q;
		}
		
		if(q.direction) {
			now = false;
			double cmp = q.point.x() - p.point.x();
			if(cmp > 0) {
				xmax = q.point.x();
				q.left = insert(q.left, p, xmin, xmax, ymin, ymax);
			}
			else {
				xmin = q.point.x();
				q.right = insert(q.right, p, xmin, xmax, ymin, ymax);
			}
			return q;
		}
		
		else {
			now = true;
			double cmp = q.point.y() - p.point.y();
			if(cmp > 0) {
				ymax = q.point.y();
				q.left = insert(q.left, p, xmin, xmax, ymin, ymax);
			}
			else {
				ymin = q.point.y();
				q.right = insert(q.right, p, xmin, xmax, ymin, ymax);
			}
			return q;
		}
	}
	 
	public boolean contains(Point2D p) {
		wrong(p);
		node q = root;
		while(true) {
			if(q == null)return false;
			if(q.point.equals(p)) return true;
			else {
				if(q.direction == true) {
					double cmp = q.point.x() - p.x();
					if(cmp > 0) q = q.left;
					else q = q.right;
				}
				else {
					double cmp = q.point.y() - p.y();
					if(cmp > 0) q = q.left;
					else q = q.right;
				}
			}
		}
	 }
	
	public void draw() {
		draw(root);
	 }
	
	private void draw(node p) {
		if(p.left != null) draw(p.left);
		if(p.right != null) draw(p.right);
		StdDraw.setPenRadius(0.05);
		StdDraw.setPenColor(StdDraw.BLACK);
		p.point.draw();
		if(!p.direction) {
			StdDraw.setPenRadius(0.01);
			StdDraw.setPenColor(StdDraw.BLUE);
			StdDraw.line(p.rect.xmin(), p.point.y(), p.rect.xmax(), p.point.y());
		}
		else {
			StdDraw.setPenRadius(0.01);
			StdDraw.setPenColor(StdDraw.RED);
			StdDraw.line(p.point.x(), p.rect.ymin(), p.point.x(), p.rect.ymax());
		}
	}
	 
	public Iterable<Point2D> range(RectHV rect) {
		wrong(rect); 
		Queue<Point2D> range = new Queue<Point2D>();
		range(root, rect, range);
		return range;
	 }
	
	private void range(node p, RectHV rect, Queue<Point2D> range) {
		if(p == null)return;
		if(!rect.intersects(p.rect))return;
		if(rect.contains(p.point))range.enqueue(p.point);
		range(p.left, rect, range);
		range(p.right, rect, range);
	}
	 
	public Point2D nearest(Point2D p) {
		wrong(p);
		if(root == null)return null;
		near = root.point;
		nearest(root, p);
		return near;
	 }
	
	private void nearest(node p, Point2D q) {
		if(p == null)return;
		if(p.point.distanceSquaredTo(q) < near.distanceSquaredTo(q)) near = p.point;
		if(p.direction) {
			if(q.x() < p.point.x()) {
				nearest(p.left, q);
				if((p.right != null)&&near.distanceSquaredTo(q) > p.right.rect.distanceSquaredTo(q)) nearest(p.right, q);
			}
			else {
				nearest(p.right, q);
				if((p.left != null)&&near.distanceSquaredTo(q) > p.left.rect.distanceSquaredTo(q)) nearest(p.left, q);
			}
			
		}
		else {
			if(q.y() < p.point.y()) {
				nearest(p.left, q);
				if((p.right != null)&&near.distanceSquaredTo(q) > p.right.rect.distanceSquaredTo(q)) nearest(p.right, q);
			}
			else {
				nearest(p.right, q);
				if((p.left != null)&&near.distanceSquaredTo(q) > p.left.rect.distanceSquaredTo(q)) nearest(p.left, q);
			}
		}
		return;
	}
	private void wrong(Point2D p) {
		if(p == null)throw new IllegalArgumentException("no input");
	 }
	private void wrong(RectHV p) {
		if(p == null)throw new IllegalArgumentException("no input");
	 }
	public static void main(String[] args) {
		/*KdTree kdtree = new KdTree();
		kdtree.insert(new Point2D(0.1, 0.1));
		kdtree.insert(new Point2D(0.2, 0.3));
		kdtree.insert(new Point2D(0.4, 0.1));
		kdtree.insert(new Point2D(0.5, 0.3));
		kdtree.insert(new Point2D(0.13, 0.17));
		kdtree.insert(new Point2D(0.0134, 0.367));
		kdtree.insert(new Point2D(0.4982, 0.17));
		kdtree.insert(new Point2D(0.1367, 0.29));
		kdtree.insert(new Point2D(0.2583, 0.236));
		kdtree.insert(new Point2D(0.9521, 0.766));
		kdtree.insert(new Point2D(0.582, 0.9346));
		kdtree.insert(new Point2D(0.471, 0.688));
		kdtree.insert(new Point2D(0.79, 0.37));
		kdtree.draw();
		StdDraw.setPenRadius(0.1);
		new Point2D(0.5, 0.6).draw();
		System.out.println(kdtree.nearest(new Point2D(0.5, 0.6)));*/
	 } 
}
