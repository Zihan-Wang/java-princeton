import edu.princeton.cs.algs4.SET;
import edu.princeton.cs.algs4.Queue;
import edu.princeton.cs.algs4.Point2D;
import edu.princeton.cs.algs4.RectHV;
import java.lang.IllegalArgumentException;


public class PointSET {
	private SET<Point2D> PS;
	public PointSET() {
		PS = new SET<Point2D>();
	}
	
	public boolean isEmpty() {
		return PS.isEmpty();
	 }
	 
	public int size() {
		return PS.size();
	 }
	 
	public void insert(Point2D p) {
		wrong(p);
		if(!PS.contains(p))PS.add(p);
	 }
	 
	public boolean contains(Point2D p) {
		wrong(p);
		return PS.contains(p);
	 }
	 
	public void draw() {
		for(Point2D p : PS) {
			 p.draw();
		 }
	 }
	 
	public Iterable<Point2D> range(RectHV rect) {
		wrong(rect);
		Queue<Point2D> PinR = new Queue<Point2D>();
		for(Point2D p : PS) {
			 if(rect.contains(p)) {
				 PinR.enqueue(p);
			 }
		 }
		 return PinR;
	 }
	 
	public Point2D nearest(Point2D p) {
		wrong(p);
		double min = -1;
		Point2D NearP = p;
		if(PS.isEmpty()) return null;
		for(Point2D h : PS) {
			double m = h.distanceSquaredTo(p);
			if(min == -1) {
				 min = m;
				 NearP = h;
			}
			if(min >= m) {
				 min = m;
				 NearP = h;
			}
		}
		return NearP;
	 }
	 
	private void wrong(Point2D p) {
		if(p == null)throw new IllegalArgumentException("no input");
	 }
	private void wrong(RectHV p) {
		if(p == null)throw new IllegalArgumentException("no input");
	 }
	public static void main(String[] args) {
	}
}
